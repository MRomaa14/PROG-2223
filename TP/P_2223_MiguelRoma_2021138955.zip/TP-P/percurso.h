#ifndef TP_P_PERCURSO_H
#define TP_P_PERCURSO_H

#include "paragem.h"
#include "linha.h"

void percursoLinhaUnica(plinha p);

// void percursoLinhaTroca(plinha p);

#endif //TP_P_PERCURSO_H
