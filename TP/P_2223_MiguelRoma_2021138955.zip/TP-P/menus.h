// Miguel Umbelino da Mota Roma - a2021138955

#ifndef TP_P_MENUS_H
#define TP_P_MENUS_H

#include "utils.h"

int menuInicial();

int menuPercurso();

int menuLinhas();

int menuParagens();

#endif //TP_P_MENUS_H
