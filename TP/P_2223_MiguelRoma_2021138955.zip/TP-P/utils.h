// Miguel Umbelino da Mota Roma - a2021138955
#ifndef TP_P_UTILS_H
#define TP_P_UTILS_H

#define MAX 100

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

void gerarCodigo(char* cod);

int lerFich(char *nomeF);

#endif
